import comp

companies = ["AMGN", "GOOG", "CVS", "NKE"]
totalGains = 0

for company in companies:
    totalGains += comp.runCompetition(company)
    print("")
    print("")
    print("")

comp.printResult(totalGains)
