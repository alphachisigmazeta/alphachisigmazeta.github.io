import hashlib
import os
from time import sleep

def check():
    h = hashlib.sha256()
    with open("comp.py", "rb", buffering=0) as f:
        for b in iter(lambda : f.read(128*1024), b''):
            h.update(b)

    hexValue = h.hexdigest()
    result = "c729f83686b36d6e7ceb77db058b9ac09401789c4350a9ed55eb9fa2ad6650fe" == hexValue
    print("Hex Value: " + hexValue)

    if(result == False):
        print("Cheater -_-, don't change the comp.py file")
        sleep(1)
        print("Reverting the comp.py file", end="")
        for i in range(5):
            print(".",end="", flush=True)
            sleep(0.25)
        print("")
        os.system("cat copycomp > comp.py")
        sleep(1)
        exit(0)
