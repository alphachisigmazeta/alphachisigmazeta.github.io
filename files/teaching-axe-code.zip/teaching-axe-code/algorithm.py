import random

def decideToBuyOrSell(price, arr, stocks):
    # Make sure to update this to 'buy' or 'sell'
    decision = ''

    # TODO: Edit me!
    if(random.randint(0,100) % 4 == 1):
        decision = 'buy'
    elif(random.randint(0,100) % 25 == 0):
        decision = 'sell'

    # Don't touch below this line
    return arr, decision
