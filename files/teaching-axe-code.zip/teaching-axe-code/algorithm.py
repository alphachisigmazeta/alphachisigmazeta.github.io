
def decideToBuyOrSell(price, arr, stocks):
    # Make sure to update this to 'buy' or 'sell'
    decision = ''

    # TODO: Edit me!
    decision = 'buy'
    arr.append(price)

    # Don't touch below this line
    return arr, decision
